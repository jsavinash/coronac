# coronavirus
I hope this project bring the necessary need what we need to solve corona virus problem.

This is the full documentation of our Project :

https://coronavirus-1.gitbook.io/general-knowledge/

#This is our bata apps:

https://coronavirus-stagibg.herokuapp.com/

#This is our live apps :

https://coronavirusbd.herokuapp.com/

# All Video In the Youtube Playlist  :

[![Youtube Corona](https://user-images.githubusercontent.com/4492335/78470086-6ee3e080-7748-11ea-9a54-f224b28dc42d.png)](https://www.youtube.com/playlist?list=PLSQ_pVMGfBaPipBOXnCze267aS8EPxe8_)


1.  How to install coronavirus project
2.  Add Contact From and Explain Pipline with Github
3.  Our Blog Feture :
4.  Our News Feture :
5.  Intro to our CSS :
6.  Heroku Migration : 
7.  Our Corona Statistic Feture :
8.  Our Curute : Write Your Name :
9.  How We Solve Problem :
10. Take all new files from Master Branch to the existing frocked Repository. :
11. What is my understanding about opesscourch
12. Opesscourch Project Responsibelity
13. App Review Facebook Problem


# Our team and There Apps  :

Name : Sushen Biswas

Repo: 
https://github.com/sushen/coronavirus/
Apps :
https://coronavirusbd.herokuapp.com/coruna/

Name : Jubel Ahmed

Repo:
https://github.com/jubelAhmed/coronavirus
Apps:
https://corunavirus19.herokuapp.com/coruna/

Name: Kamrul Hasan

Repo:
https://github.com/kmrul/coronavirus
Apps:
https://coronaproject.herokuapp.com/coruna/










